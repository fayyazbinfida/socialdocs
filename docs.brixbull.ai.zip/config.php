<?php
session_start();
    // $_SESSION['PATH'] = 'http://localhost/doc.brixbull.ai';
    $_SESSION['PATH'] = 'http://brixbull.ai/docs';

?>